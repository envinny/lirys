<?php
#fichier destiné à charger toute les class request2
require_once "request/vendor/pear/net_url2/Net/URL2.php";
require_once 'request/vendor/pear/pear_exception/PEAR/Exception.php';
require_once 'request/vendor/pear/http_request2/HTTP/Request2/Exception.php';
require_once 'request/vendor/pear/http_request2/HTTP/Request2/ConnectionException.php';
require_once 'request/vendor/pear/http_request2/HTTP/Request2/Response.php';
require_once 'request/vendor/pear/http_request2/HTTP/Request2/SocketWrapper.php';
require_once 'request/vendor/pear/http_request2/HTTP/Request2/Adapter.php';
require_once 'request/vendor/pear/http_request2/HTTP/Request2/Adapter/Socket.php';
require_once 'request/vendor/pear/http_request2/HTTP/Request2.php';



?>